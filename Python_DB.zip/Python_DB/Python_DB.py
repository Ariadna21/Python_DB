import sqlite3 as sql
import click
import io
import os
import cclib
from PIL import Image
import tkinter as tk
from tkinter import filedialog
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import csv
from tabulate import tabulate
import base64
from PIL import Image
import subprocess


db = "test.db"
connection = sql.connect(db)


c = connection.cursor()

def convertToBinaryData(filename):
    with open(filename, 'rb') as file:
        blobData = file.read()
    return blobData



def select_folders():
    root = tk.Tk()
    root.withdraw()  # Hide the root window
    folder_selected = filedialog.askdirectory(title="Select Root Directory")
    root_folders = []
    for dirpath, dirnames, filenames in os.walk(folder_selected):
        if dirpath == folder_selected:  # Check if the current directory is the root directory
            for dirname in dirnames:
                root_folders.append(os.path.join(folder_selected, dirname))
    return root_folders
def select_folder():
    folder_path = filedialog.askdirectory()
    if folder_path:
        print("Selected folder:", folder_path)
    return folder_path    
def select_file():
    root = tk.Tk()
    root.withdraw()  # Hide the main window

    file_path = filedialog.askopenfilename(title="Select a file")

    if file_path:
        print(f"Selected file: {file_path}")
    return file_path
# for multiple files to open
def select_files():
    root = tk.Tk()
    root.withdraw()  # Hide the main window

    file_paths = filedialog.askopenfilenames(title="Select files")

    if file_paths:
        print("Selected files:")
        for file_path in file_paths:
            print(file_path)
    return file_paths
def analyze_folder(folder_path):
    all_files = []
    calcf_ph =[]
    for file_name in os.listdir(folder_path): 
        if file_name.endswith(".com"):
            inp_nm = file_name
            inp_file_ph = os.path.join(folder_path, file_name)
            inp_data = convertToBinaryData(inp_file_ph)        
            all_files.append(inp_nm)
            all_files.append(inp_data)
        elif file_name.endswith(".xyz") or file_name.endswith(".inp") or file_name.endswith(".pdb") and "input" in file_name.lower():
            geomi_nm = file_name
            geomi_file_ph = os.path.join(folder_path, file_name)
            geomi_data = convertToBinaryData(geomi_file_ph)
            all_files.append(geomi_nm)
            all_files.append(geomi_data)
            print(geomi_nm)
        #elif file_name.endswith(".log"):
        elif file_name.endswith(".log") and ("input" in file_name.lower() or "output" in file_name.lower()):
            calc_nm = file_name
            calc_file_ph = os.path.join(folder_path, file_name)
            calc_data = convertToBinaryData(calc_file_ph)
            all_files.append(calc_nm)
            calcf_ph.append(calc_file_ph)
            all_files.append(calc_data)
    #checks if there is no .com files
    if len(all_files) == 4:
        #all_files.insert(0, "No .com files found.")
        all_files.insert(0, None)
        all_files.insert(1, "No .com files found.")
        print(all_files[1])
    return all_files, calc_file_ph
def process_log_files(root_dir):

    log_files = []
    subdir_path = root_dir  # Assuming root_dir is the main directory
    subdirectories = sorted(next(os.walk(subdir_path))[1], key=lambda x: float(x[1:]))  # Get sorted list of subdirectories numerically

    for subdir in subdirectories:
        subdir_path = os.path.join(root_dir, subdir)
        for dirpath, _, filenames in os.walk(subdir_path):
            for filename in filenames:
                 if filename.endswith('.log') and ('input.log' in filename or 'output.log' in filename):
                    log_file_path = os.path.join(dirpath, filename)
                    log_files.append(log_file_path)
    return log_files


@click.command() 
@click.option('--key_word', prompt='Enter molecule keyword', help='Molecule keyword')
@click.option('--title', prompt='Enter job title', help='Job title')
@click.option('--author', prompt='Enter author name', help='Author name')
def insert_all2(key_word, title, author):   
    dataTulpeMol = (key_word,)
    #pasirenka molekules pavadinima
    c.execute("SELECT keyword FROM Molekules WHERE keyword=?", (key_word,))
    result = c.fetchone()
    #Check if molecule exist or not in the table aready
    #check if result is not none
    if result:
        click.echo("molecule exist")
        c.execute("SELECT molecule_id FROM Molekules WHERE keyword=?", (result))
        last_molecule_id = int(c.fetchone()[0]) 
        
    # if result is none
    else:
        click.echo("molecule do not exist")
        c.execute("INSERT INTO Molekules (keyword) VALUES (?)", dataTulpeMol)
        c.execute("SELECT molecule_id FROM Molekules ORDER BY molecule_id DESC LIMIT 1")
        last_molecule_id = int(c.fetchone()[0] or 0)
       
        
    user_input1 = click.prompt("Do you want to upload files? (y/n)", show_default=False, default='')
    
    if user_input1.lower() == 'y':
        user_input2 = click.prompt("Do you want to upload one or more files (o/m)", show_default=False, default='')
        #insert one folder with calculations
        if user_input2.lower() == 'o':
            click.echo("Select one folder")
            folder_path = select_folder()
            all_files, calcf_ph = analyze_folder(folder_path)           
            print(calcf_ph)
            extr_data = data_skaic_cclib(calcf_ph)
            dataTulpSkaic = (last_molecule_id, key_word,title,extr_data[3],extr_data[2],extr_data[1], author)
            c.execute("INSERT INTO  Skaiciavymai (molecule_id, keyword, title, program, method, basis_set, author) VALUES(?,?,?,?,?,?,?)", dataTulpSkaic)
            c.execute("SELECT id_sk FROM Skaiciavymai ORDER BY id_sk DESC LIMIT 1")
            last_skaic_id = int(c.fetchone()[0] or 0)
            input_nm, input_data,geom_nm, geom_data, calc_nm, calc_data = all_files[:6]
            dataTulpAlld = (last_skaic_id, geom_nm, geom_data, input_nm, input_data, calc_nm, calc_data)           
            c.execute("INSERT INTO  All_data (id_sk, geom_nm, geom_data, input_nm, input_data, calc_nm, calc_data) VALUES(?,?,?,?,?,?,?)", dataTulpAlld)
            click.echo("All data was successfully inserted ")
        #insert many folders with calculations, by selecting root folder
        elif user_input2.lower() == 'm':
            click.echo("Select root folder containing multiple folders of calculations")
            program=method=basis_set=input_nm=calc_nm= 'More than one'
            dataTulpSkaic = (last_molecule_id, key_word,title,program,method,basis_set,author)           
            c.execute("INSERT INTO  Skaiciavymai (molecule_id, keyword, title, program, method, basis_set, author) VALUES(?,?,?,?,?,?,?)", dataTulpSkaic)
            c.execute("SELECT id_sk FROM Skaiciavymai ORDER BY id_sk DESC LIMIT 1")
            last_skaic_id = int(c.fetchone()[0] or 0)
            folders = select_folders()
            #for folder path in root folder path
            for folder in folders:
                click.echo(folder)
                all_files, calcf_ph = analyze_folder(folder)
                input_nm, input_data,geom_nm, geom_data, calc_nm, calc_data = all_files[:6]
                input_data2 = calc_data2 = "More than one"
                dataTulpAlld = (last_skaic_id, geom_nm, geom_data,input_nm,input_data2, calc_nm, calc_data2)
                c.execute("INSERT INTO  All_data (id_sk, geom_nm, geom_data, input_nm, input_data, calc_nm, calc_data) VALUES(?,?,?,?,?,?,?)", dataTulpAlld)
                extr_data = data_skaic_cclib(calcf_ph)
                c.execute("SELECT id_dm FROM All_data ORDER BY id_dm DESC LIMIT 1")
                last_Daugskaic_id = int(c.fetchone()[0] or 0)
                dataTulpDaugiauSk = (last_Daugskaic_id,input_nm, input_data, extr_data[0],calc_data,extr_data[3], extr_data[2], extr_data[1])
                c.execute("INSERT INTO  Daugiau_Skaic (id_dm, input_nm,input_data,calc_nm, calc_data, program, method, basis_set) VALUES(?,?,?,?,?,?,?,?)", dataTulpDaugiauSk)                
            click.echo("All data was successfully inserted ")
    elif user_input1.lower() == 'n':
        click.echo('You decided to leave')    

    connection.commit()
    connection.close()
# for extraction of basic inform. using cclib
def data_skaic_cclib(file_path):
    data = cclib.io.ccopen(file_path).parse()
    file_name = os.path.basename(file_path)            
    basis_set = data.metadata.get('basis_set', 'Basis set not found')
    method = data.metadata.get('functional', 'Density functional set not found')            
    package = data.metadata.get('package', 'Package not found')
    return file_name,basis_set,method, package



@click.command()
def delete_data():
    user_input = click.prompt("Delete the record by molecule, author name or job title (m/a/t)", show_default=False, default='')
    # by specified filter delete from tables all asociated data
    if user_input.lower() == 'm':
        user_mol = click.prompt("Enter molecule name", show_default=False, default='')       
        c.execute("SELECT Skaiciavymai.id_sk, Skaiciavymai.keyword,Skaiciavymai.title,\
        Skaiciavymai.program, Skaiciavymai.method, Skaiciavymai.basis_set, Skaiciavymai.author \
        FROM Skaiciavymai INNER JOIN Molekules ON Skaiciavymai.molecule_id=Molekules.molecule_id \
        WHERE Molekules.keyword =?", (user_mol,))
        click.echo(f"All asociated data of molecule {user_mol}")
        rows = c.fetchall()        
        for row in rows:
            click.echo(row)
        user_choise = click.prompt("Do you want to delete the data provided (y/n)?", show_default=False, default='')
        if user_choise.lower() == 'y':
            c.execute("DELETE FROM Daugiau_Skaic WHERE id_dm IN ( \
               SELECT id_dm FROM All_data WHERE id_sk IN ( \
                   SELECT id_sk FROM Skaiciavymai WHERE molecule_id IN ( \
                       SELECT molecule_id FROM Molekules WHERE keyword = ? \
                   ) \
               ) \
           )", (user_mol,))
            c.execute("DELETE FROM All_data WHERE id_sk IN ( \
               SELECT id_sk FROM Skaiciavymai WHERE molecule_id IN ( \
                   SELECT molecule_id FROM Molekules WHERE keyword = ? \
               ) \
           )", (user_mol,))
            c.execute("DELETE FROM Skaiciavymai WHERE molecule_id IN ( \
               SELECT molecule_id FROM Molekules WHERE keyword = ? \
           )", (user_mol,))
            c.execute("DELETE FROM Molekules WHERE keyword = ?", (user_mol,))

            click.echo("Deleted sucessfully! ")
        else:
            click.echo("You decided to leave")
    elif user_input.lower() == 'a':
        user_mol = click.prompt("Enter author name", show_default=False, default='')
        c.execute("SELECT Skaiciavymai.id_sk, Skaiciavymai.keyword,Skaiciavymai.title,\
        Skaiciavymai.program, Skaiciavymai.method, Skaiciavymai.basis_set, Skaiciavymai.author \
        FROM Skaiciavymai INNER JOIN Molekules ON Skaiciavymai.molecule_id=Molekules.molecule_id \
        WHERE Skaiciavymai.author =?", (user_mol,))
        click.echo(f"All asociated data of author {user_mol}")
        rows = c.fetchall()        
        for row in rows:
            click.echo(row) 
        user_choise = click.prompt("Do you want to delete the data provided (y/n) ?", show_default=False, default='')
        if user_choise.lower() == 'y':
            c.execute("DELETE FROM Daugiau_Skaic WHERE id_dm IN ( \
               SELECT id_dm FROM All_data WHERE id_sk IN ( \
                   SELECT id_sk FROM Skaiciavymai WHERE author = ? \
               ) \
           )", (user_mol,))

            c.execute("DELETE FROM All_data WHERE id_sk IN ( \
                        SELECT id_sk FROM Skaiciavymai WHERE author = ? \
                    )", (user_mol,))

            c.execute("DELETE FROM Skaiciavymai WHERE author = ?", (user_mol,))
            click.echo("Deleted sucessfully! ")
        else:
            click.echo("You decided to leave")
    elif user_input.lower() == 't':
        user_mol = click.prompt("Enter job title", show_default=False, default='')
        c.execute("SELECT Skaiciavymai.id_sk, Skaiciavymai.keyword,Skaiciavymai.title,\
        Skaiciavymai.program, Skaiciavymai.method, Skaiciavymai.basis_set, Skaiciavymai.author \
        FROM Skaiciavymai INNER JOIN Molekules ON Skaiciavymai.molecule_id=Molekules.molecule_id \
        WHERE Skaiciavymai.title =?", (user_mol,))
        print("Molecules choosen")
        click.echo(f"All asociated data of job title {user_mol}")
        rows = c.fetchall()        
        for row in rows:
            click.echo(row) 
        user_choise = click.prompt("Do you want to delete the data provided (y/n)?", show_default=False, default='')
        if user_choise.lower() == 'y':
            c.execute("DELETE FROM Daugiau_Skaic WHERE id_dm IN ( \
               SELECT id_dm FROM All_data WHERE id_sk IN ( \
                   SELECT id_sk FROM Skaiciavymai WHERE title = ? \
               ) \
           )", (user_mol,))

            c.execute("DELETE FROM All_data WHERE id_sk IN ( \
                        SELECT id_sk FROM Skaiciavymai WHERE title = ? \
                    )", (user_mol,))

            c.execute("DELETE FROM Skaiciavymai WHERE title = ?", (user_mol,))
            click.echo("Deleted sucessfully! ")
        else:
            click.echo("You decided to leave")
    connection.commit()
    connection.close()

@click.command()
def select_data2():
    user_input = click.prompt("Select molecule, author name or job title (m/a/t)", show_default=False, default='')
    if user_input.lower() == 'm':
        user_mol = click.prompt("Enter molecule name", show_default=False, default='')       
        c.execute("SELECT Skaiciavymai.id_sk, Skaiciavymai.keyword,Skaiciavymai.title,\
        Skaiciavymai.program, Skaiciavymai.method, Skaiciavymai.basis_set, Skaiciavymai.author \
        FROM Skaiciavymai INNER JOIN Molekules ON Skaiciavymai.molecule_id=Molekules.molecule_id \
        WHERE Molekules.keyword =?", (user_mol,))
        #print all asociated data to user
        click.echo(f"All asociated data with molecule name {user_mol}")
        rows = c.fetchall()        
        for row in rows:
            click.echo(row) 
        # Create a new table for selected data
        c.execute('''CREATE TABLE IF NOT EXISTS NewTable (id_sk integer, keyword TEXT,
                        title TEXT,program TEXT,method TEXT,basis_set TEXT, author TEXT
                    )''')
        c.executemany("INSERT INTO NewTable VALUES (?, ?, ?, ?, ?, ?, ?)",rows)   
        user_input1 = click.prompt(
        "\n1. Option - p, program\n" "2. Option - mt, method\n" "3. Option - b, basis set\n" "4. Option - t, title\n"
        "5. Option - a, author\n" "Select how you want to display data", show_default=False, default='')
    #filter selected data 
    elif user_input.lower() == 'a':
        user_mol = click.prompt("Enter author name", show_default=False, default='')
        c.execute("SELECT Skaiciavymai.id_sk, Skaiciavymai.keyword,Skaiciavymai.title,\
        Skaiciavymai.program, Skaiciavymai.method, Skaiciavymai.basis_set, Skaiciavymai.author \
        FROM Skaiciavymai INNER JOIN Molekules ON Skaiciavymai.molecule_id=Molekules.molecule_id \
        WHERE Skaiciavymai.author =?", (user_mol,))
        print("Molecules choosen")
        click.echo(f"All asociated data of author {user_mol}")
        rows = c.fetchall()        
        for row in rows:
            click.echo(row) 

        c.execute('''CREATE TABLE IF NOT EXISTS NewTable (id_sk integer, keyword TEXT,
                        title TEXT,program TEXT,method TEXT,basis_set TEXT, author TEXT
                    )''')
        c.executemany("INSERT INTO NewTable VALUES (?, ?, ?, ?, ?, ?, ?)",rows)        
        user_input1 = click.prompt(
        "\n1. Option - p, program\n" "2. Option - mt, method\n" "3. Option - b, basis set\n" "4. Option - t, title\n"
        "5. Option - m, molecule\n" "Select how you want to display data", show_default=False, default='')

    elif user_input.lower() == 't':
        user_mol = click.prompt("Enter job title", show_default=False, default='')
        c.execute("SELECT Skaiciavymai.id_sk, Skaiciavymai.keyword,Skaiciavymai.title,\
        Skaiciavymai.program, Skaiciavymai.method, Skaiciavymai.basis_set, Skaiciavymai.author \
        FROM Skaiciavymai INNER JOIN Molekules ON Skaiciavymai.molecule_id=Molekules.molecule_id \
        WHERE Skaiciavymai.title =?", (user_mol,))
        print("Molecules choosen")
        click.echo(f"All asociated data of author {user_mol}")
        rows = c.fetchall()        
        for row in rows:
            click.echo(row) 
        print("Title choosen")
        c.execute('''CREATE TABLE IF NOT EXISTS NewTable (id_sk integer, keyword TEXT,
                        title TEXT,program TEXT,method TEXT,basis_set TEXT, author TEXT
                    )''')
        c.executemany("INSERT INTO NewTable VALUES (?, ?, ?, ?, ?, ?, ?)",rows)
        user_input1 = click.prompt(
        "\n1. Option - p, program\n" "2. Option - mt, method\n" "3. Option - b, basis set\n"
        "4. Option - m, molecule\n" "5. Option - a, author\n" "Select how you want to display data", show_default=False, default='')
    if user_input1 == 'p':
        user_input2 = click.prompt("Enter the program name", show_default=False, default='')            
        c.execute("SELECT * FROM NewTable WHERE program=? OR program='More than one'", (user_input2,))
        new_table_content = c.fetchall()
        click.echo("Content of associated data:")
        for row in new_table_content:
            click.echo(row)
    elif user_input1 == 'm':
        user_input2 = click.prompt("Enter the molecule name", show_default=False, default='')            
        c.execute("SELECT * FROM NewTable WHERE keyword=?", (user_input2,))
        new_table_content = c.fetchall()
        click.echo("Content of associated data:")
        for row in new_table_content:
            click.echo(row)

    elif user_input1 == 'mt':
        user_input2 = click.prompt("Enter the method", show_default=False, default='')            
        c.execute("SELECT * FROM NewTable WHERE method=? OR method='More than one'", (user_input2,))
        new_table_content = c.fetchall()
        click.echo("Content of associated data:")
        for row in new_table_content:
            click.echo(row)
    elif user_input1 == 'b':
        user_input2 = click.prompt("Enter the basis set", show_default=False, default='')            
        c.execute("SELECT * FROM NewTable WHERE basis_set=? OR basis_set='More than one'", (user_input2,))
        new_table_content = c.fetchall()
        click.echo("Content of associated data:")
        for row in new_table_content:
            click.echo(row)
    elif user_input1 == 't':
        user_input2 = click.prompt("Enter the job title", show_default=False, default='')            
        c.execute("SELECT * FROM NewTable WHERE title=? OR title='More than one'", (user_input2,))
        new_table_content = c.fetchall()
    elif user_input1 == 'a':
        user_input2 = click.prompt("Enter the author name", show_default=False, default='')            
        c.execute("SELECT * FROM NewTable WHERE author=?", (user_input2,))
        new_table_content = c.fetchall()
        click.echo("Content of associated data:")
        for row in new_table_content:
            click.echo(row)
    else:
        click.echo("you chose the wrong option")
    #deleting the content of temporary table
    c.execute("DELETE FROM NewTable")
    for item in new_table_content:
        c.execute("INSERT INTO NewTable VALUES (?, ?, ?, ?, ?, ?, ?)", item)
    if new_table_content:
        click.echo("All data was selected sucessfully")
        
    #download files
    user_input3 = click.prompt("Do you want to download calc files (y/n)", show_default=False, default='')
    
    if user_input3 == 'y':
        #firstly selecting all files associted with selected data
        #for files with one calculation
        c.execute("SELECT NewTable.title, NewTable.author, All_data.geom_nm, All_data.geom_data, All_data.input_nm,All_data.input_data,\
        All_data.calc_nm,All_data.calc_data \
        FROM NewTable \
        INNER JOIN All_data ON NewTable.id_sk = All_data.id_sk ")
        files1 = c.fetchall()
        sorted_f1=[]
        #checks if fyle type are bytes, to print files consisting of one caclulation 
        for f in files1:                
            if isinstance(f[7], bytes):
                sorted_f1.append(f)
        for s in sorted_f1:
            click.echo(f"{s[0]} {s[1]} {s[2]} {s[4]} {s[6]}")    
        #for files with more than one calculation
        c.execute("SELECT NewTable.title, NewTable.author, All_data.geom_nm, All_data.geom_data, \
        Daugiau_Skaic.input_nm, Daugiau_Skaic.input_data, Daugiau_Skaic.calc_nm, Daugiau_Skaic.calc_data \
        FROM NewTable \
        INNER JOIN All_data ON NewTable.id_sk = All_data.id_sk \
        INNER JOIN Daugiau_Skaic ON All_data.id_dm = Daugiau_Skaic.id_dm")
        files2 = c.fetchall()
        data = {}
        for f in files2:
            identifier = f[0]
            author = f[1]
            files_info = f[2], f[4], f[6]
            if author not in data:
                data[author] = {"identifier": identifier, "files_info_list": []}
            data[author]["files_info_list"].append(files_info)
        for author, info in data.items():
            click.echo(f"{author}:")
            identifier = info["identifier"]
            print(f"Job title: {identifier}")
            for files_info in info["files_info_list"]:
                files_info_filtered = [file_info for file_info in files_info if file_info is not None]
                # Join the non-None values into a string
                files_info_str = ', '.join(files_info_filtered)
                print(f"Calculation files: {files_info_str}")
            print("\n")       
        # download files into specified directory    
        user_input4_dir = click.prompt("Enter the directory where you want to save the files", show_default=False, default='')            
        if not os.path.exists(user_input4_dir):
            os.makedirs(user_input4_dir) 
        geom_filename = None
        input_filename = None
        calc_filename = None
        # for data in All_data table
        for index, f in enumerate(sorted_f1):
            geom_nm, geom_data, input_nm, input_data, calc_nm, calc_data = f[2], f[3], f[4], f[5], f[6], f[7]
            geom_filename = f"{index}_{geom_nm}"
            input_filename = f"{index}_{input_nm}"
            calc_filename = f"{index}_{calc_nm}"
            with open(os.path.join(user_input4_dir, geom_filename), 'wb') as file:
                file.write(geom_data)   
            if not isinstance(input_data, str):  # Check if input_data is not a string
                with open(os.path.join(user_input4_dir, input_filename), 'wb') as file:
                    file.write(input_data)                 
            with open(os.path.join(user_input4_dir, calc_filename), 'wb') as file:
                file.write(calc_data) 
        if geom_filename is not None and input_filename is not None and calc_filename is not None:
            if all([os.path.exists(geom_filename), os.path.exists(input_filename), os.path.exists(calc_filename)]):
                print("Files downloaded successfully.")
        else:
            print("Check the downloaded files.")
        #for data in Daugiau_skaic table 
        for index, f in enumerate(files2,start=len(sorted_f1)):
            geom_nm, geom_data, input_nm, input_data, calc_nm, calc_data = f[2], f[3], f[4], f[5], f[6], f[7]
            geom_filename = f"{index}_{geom_nm}"
            input_filename = f"{index}_{input_nm}"
            calc_filename = f"{index}_{calc_nm}"
            with open(os.path.join(user_input4_dir, geom_filename), 'wb') as file:
                file.write(geom_data)        
            if not isinstance(input_data, str):  # Check if input_data is not a string
                with open(os.path.join(user_input4_dir, input_filename), 'wb') as file:
                    file.write(input_data)       
            with open(os.path.join(user_input4_dir, calc_filename), 'wb') as file:
                file.write(calc_data)  
        click.echo("Data was successfully downloaded")
    else:
        click.echo("You decided to leave")
    c.execute("DROP TABLE IF EXISTS NewTable")
    connection.commit()
    connection.close()

@click.command()
def pirmas_grafikas():
    
    click.echo("Welcome to the Distance dependence of the excited energies analysis")
    user_input4 = click.prompt("Do you want to select or insert data (s/i)", show_default=False, default='')
    if user_input4 == 'i':
        numbers_input = click.prompt('Enter a range of z coordinates separated by commas',show_default=False, default='')
        click.echo('Select root folder of your calculations')
        all_z_dist = [float(num.strip()) for num in numbers_input.split(',')]
        #all_z_dist = [0,5,10,50,100, 200]
        monomer_exc_ev = 0
        all_exited_ev, scf_arr2, f_value = [], [], [], 
        # pasirinkti viena pagrindini folderi su visais .log failais
        selected_folder = select_folder()
        log_file_paths = process_log_files(selected_folder)
        print("Log file paths:")
        for path in log_file_paths:
            print(path)
            data = cclib.io.ccopen(path).parse()        
            energies_1_cm = data.etenergies
            scf_en = data.scfenergies # original data is in hartre cclib converts to ev
            f_v = data.etoscs
            scf_arr2.append(scf_en)
            f_value.append(f_v)
            # Conversion factor from 1/cm to eV
            conversion_factor = 8065.54429
            energies_eV = [(energy / conversion_factor) for energy in energies_1_cm]
            all_exited_ev.append(energies_eV[0])
            all_exited_ev.append(energies_eV[1])
       
        #monomerui

        click.echo("Select .log file for mononer")
        monomer_fph= select_file()
        data = cclib.io.ccopen(monomer_fph).parse()
        energies_1_cm_m = data.etenergies
        energies_eV_m = [(energy / conversion_factor) for energy in energies_1_cm_m]
        monomer_exc_ev = energies_eV_m[0]        
        print(f"Monomer energy {monomer_exc_ev}/eV")
        
        # Flatten the nested arrays and convert to numpy array
        scf_list = np.array([val[0] for val in scf_arr2])
        x_values1 = []
        y_values1 = []
        x_values2 = []
        y_values2 = []
        for i in range(len(all_z_dist)):
            if 2*i < len(all_exited_ev):
                x_values1.append(all_z_dist[i])
                y_values1.append(all_exited_ev[2*i])
            if 2*i+1<len(all_exited_ev):
                x_values2.append(all_z_dist[i])
                y_values2.append(all_exited_ev[2*i+1])
    

        # save to .txt
        columns = ['R', 'S1/eV', 'S2/eV', 'E0/eV']
        data_txt = list(zip(all_z_dist,y_values1,y_values2,scf_list))
        click.echo('Extracted data')
        click.echo(tabulate(data_txt, headers=columns))
    
        with open('data.txt', 'w', newline='') as file:
            writer = csv.writer(file, delimiter='\t')  # Using tab delimiter for .txt file
            writer.writerow(columns)  # Write column names
            writer.writerows(data_txt)  # Write data
        #plot graph    

        # Plot the data
        fig, ax = plt.subplots()
        ax.plot(x_values1, y_values1, color='black', marker='s', markersize=5, markerfacecolor='white', label=r'State S$_{1}$', linewidth=0.5)

        # Plot the second line (white with square dots)
        ax.plot(x_values2, y_values2, color='black', marker='o', markersize=5, label='State S$_{2}$', linewidth=0.5)
        ax.axhline(y=monomer_exc_ev, color='red', linestyle='--', label='Monomer state S$_{1}$')

        ax.set_xlabel(r'z, Å', fontsize=14)
        ax.set_ylabel('E, eV', fontsize=14)
        ax.set_title('Distance dependence of the excited energies', fontsize=14)
        ax.legend()
        plt.show()
        # Save the plot as bytes
        buffer = io.BytesIO()
        fig.savefig(buffer, format='png')
        buffer.seek(0)
        graph = buffer.read()

        #insert data to database
        user_input3 = click.prompt("Do you want to insert calculations to database? (y/n)", show_default=False, default='')       
        if user_input3=='y':
            title = click.prompt("Enter the job title", show_default=False, default='')
            # Write the data to the text file
            with open('data.txt', 'w', newline='') as file:
                writer = csv.writer(file, delimiter='\t')
                writer.writerow(columns)
                writer.writerows(data_txt)
            # Read the file as binary data
            with open('data.txt', 'rb') as file:
                file_data = file.read()
            c.execute("INSERT INTO Suzad_atstumas (title,txt_file,graph) VALUES (?,?,?)", (title,file_data,graph))
            click.echo('Data was inserted sucessfully')
        else:
            click.echo('Calculations are finished')    
        os.remove('data.txt')
        connection.commit()
        connection.close()
    elif user_input4 == 's':
        click.echo("All data")
        c.execute('SELECT title FROM Suzad_atstumas')
        all_titles = c.fetchall()
        for t in all_titles:
            click.echo(t)
        while True:
            user_input6 = click.prompt("Enter the job title", show_default=False, default='')
            c.execute('SELECT txt_file FROM Suzad_atstumas WHERE title=?', (user_input6,))
            data_t = c.fetchall()
            if data_t:
                for row in data_t:
                    txt_file = row[0]
                    txt_file_str = txt_file.decode('utf-8')
                    lines = txt_file_str.split('\n')
                    for line in lines:
                        click.echo(line)
            c.execute('SELECT graph FROM Suzad_atstumas WHERE title=?', (user_input6,))
            graph_data = c.fetchone()
            if graph_data:
                buffer = io.BytesIO(graph_data[0])
                buffer.seek(0)
                plt.figure()
                img = plt.imread(buffer)
                plt.imshow(img)
                plt.axis('off')
                plt.show()
            user_input5 = click.prompt("Do you want to see more jobs?(y/n)", show_default=False, default='')
            if user_input5.lower() != 'y':
                click.echo("You decided to leave")
                break
        connection.commit()
        connection.close()



def antras_grafikas_2():
    click.echo("Welcome to the Raman and absorbtion spectrum of carotenoids analysis")
    user_input4 = click.prompt("Do you want to select or insert data (s/i)", show_default=False, default='')
    if user_input4 == 'i':
        click.echo("Select root folder with raman calculations")
        selected_folder = select_folder()
        all_top_freq, all_excited_ev = [],[]
        log_file_paths = process_log_files(selected_folder)
        print("Log file paths:")
        for path in log_file_paths:
            print(path)
            data = cclib.io.ccopen(path).parse()
    
            vibfreqs = data.vibfreqs
            vibirs = data.vibirs
            vibramans = data.vibramans
            result = [item for sublist in zip(vibfreqs, vibirs, vibramans) for item in sublist]

            # in blocks 
            two_dimensional_list = []
            for i in range(0, len(result), 3):
                two_dimensional_list.append(result[i:i+3])   

            freq= [sublist[0] for sublist in two_dimensional_list]
            intens= [sublist[1] for sublist in two_dimensional_list]
            raman = [sublist[2] for sublist in two_dimensional_list]
    
            filtered_freq = [f for f in freq if f <= 2000]
            filtered_raman = [raman[i] for i, f in enumerate(freq) if f <= 2000]
    
            top_three_indices = np.argsort(filtered_raman)[-3:][::-1]
            top_three_freq = [filtered_freq[i] for i in top_three_indices]
            top_three_intens = [filtered_raman[i] for i in top_three_indices]
        
            all_top_freq.append(top_three_freq[0])
            for i, (freq, raman) in enumerate(zip(top_three_freq, top_three_intens), start=1):
                print(f"Peak {i}: Frequency = {freq}, Intensity = {raman}")
    
        click.echo("Select root folder with TD calculations")
        selected_folder2 = select_folder()
        log_file_paths2 = process_log_files(selected_folder2)
        print("Log file paths:")
        extract_file_name = [path.split("\\")[1] for path in log_file_paths2]

        print(extract_file_name)  # Output: ['c0', 'c1', 'c2']
        for path in log_file_paths2:
             print(path)
             data = cclib.io.ccopen(path).parse() 
             energies_1_cm = data.etenergies
         
             conversion_factor = 8065.54429
             energies_eV = [(energy / conversion_factor) for energy in energies_1_cm]
             all_excited_ev.append(energies_eV[0])
        plt.figure(figsize=(8, 6))
   
       # label_names = ['Beta-Carotene','Liutein', 'Lycopene (N=11)', 'Neurospore (N=9)', 'Spheroidenone (N=10)',]
        # Perform linear regression
        slope, intercept = np.polyfit(all_top_freq, all_excited_ev, 1)
        line_x = np.linspace(min(all_top_freq), max(all_top_freq), 100)
        line_y = slope * line_x + intercept        
        #for i, (x, y) in enumerate(zip(all_top_freq, all_excited_ev), start=1):
        #    plt.scatter(x, y, marker='s', color='black')
        #    plt.annotate(label_names[i-1], (x, y), textcoords="offset points", xytext=(0,10), ha='center', fontsize=14)
        #plt.plot(line_x, line_y, linestyle='--', linewidth=1, color='black')

        # save to .txt
        columns = ['S1/eV', 'F/cm^-1']
        data_txt = list(zip(all_excited_ev,all_top_freq))
        click.echo('Extracted data')
        click.echo(tabulate(data_txt, headers=columns))
    
        with open('data.txt', 'w', newline='') as file:
            writer = csv.writer(file, delimiter='\t')  # Using tab delimiter for .txt file
            writer.writerow(columns)  # Write column names
            writer.writerows(data_txt)  # Write data
        fig, ax = plt.subplots()
        #for main function
        for i, (x, y) in enumerate(zip(all_top_freq, all_excited_ev), start=1):
            ax.scatter(x, y, marker='s', color='black')
            #plt.plot(x, y, linestyle='-', linewidth=0.5, color='gray')
            ax.annotate(extract_file_name[i-1], (x, y), textcoords="offset points", xytext=(0,10), ha='center')
        # Plot the regression line
        ax.plot(line_x, line_y, linestyle='--', linewidth=1, color='black')
        ax.set_xlabel('Frequency, cm$^{-1}$', fontsize=14)
        ax.set_ylabel('E, eV', fontsize=14)
        ax.set_title('Correlation between v1 Raman bond position and S1 excited state energy', fontsize=14)
        ax.legend()
        ax.grid(True)
        plt.show()
         # Save the plot as bytes
        buffer = io.BytesIO()
        fig.savefig(buffer, format='png')
        buffer.seek(0)
        graph = buffer.read()
        #insert data to database
        user_input3 = click.prompt("Do you want to insert calculations to database? (y/n)", show_default=False, default='')       
        if user_input3=='y':
            title = click.prompt("Enter the job title", show_default=False, default='')
            # Write the data to the text file
            with open('data.txt', 'w', newline='') as file:
                writer = csv.writer(file, delimiter='\t')
                writer.writerow(columns)
                writer.writerows(data_txt)
            # Read the file as binary data
            with open('data.txt', 'rb') as file:
                file_data = file.read()
            c.execute("INSERT INTO Raman_absorb (title,txt_file,graph) VALUES (?,?,?)", (title,file_data,graph))
            click.echo('Data was inserted sucessfully')
        else:
            click.echo('Calculations are finished')    
        os.remove('data.txt')
        connection.commit()
        connection.close()
    elif user_input4 == 's':
        click.echo("All data")
        c.execute('SELECT title FROM Raman_absorb')
        all_titles = c.fetchall()
        for t in all_titles:
            click.echo(t)
        while True:
            user_input6 = click.prompt("Enter the job title", show_default=False, default='')
            c.execute('SELECT txt_file FROM Raman_absorb WHERE title=?', (user_input6,))
            data_t = c.fetchall()
            if data_t:
                for row in data_t:
                    txt_file = row[0]
                    txt_file_str = txt_file.decode('utf-8')
                    lines = txt_file_str.split('\n')
                    for line in lines:
                        click.echo(line)
            c.execute('SELECT graph FROM Raman_absorb WHERE title=?', (user_input6,))
            graph_data = c.fetchone()
            if graph_data:
                buffer = io.BytesIO(graph_data[0])
                buffer.seek(0)
                plt.figure()
                img = plt.imread(buffer)
                plt.imshow(img)
                plt.axis('off')
                plt.show()
            user_input5 = click.prompt("Do you want to see more jobs?(y/n)", show_default=False, default='')
            if user_input5.lower() != 'y':
                click.echo("You decided to leave")
                break
        connection.commit()
        connection.close()

@click.command()
def jmol():
    user_input = click.prompt("Hello! Would you like to run the Jmol? (y/n)", show_default=False, default='')    
    if user_input.lower() == 'y':
        click.echo("Select file to open:")
        file_path = select_file()
        jmol_jar = "Jmol.jar"
        subprocess.run(["java", "-jar", jmol_jar, file_path])
    elif user_input.lower() == 'n':
        click.echo("Goodbye")

@click.command()
def graph_viz():
    click.echo("Welcome to calculations vizualization!")
    user_input4 = click.prompt("Do you want to select or insert data (s/i)", show_default=False, default='')
    if user_input4 == 'i':
        num_x_axes = int(click.prompt("Enter the number of x-axes",show_default=False, default=''))
        num_y_axes = int(click.prompt("Enter the number of y-axes",show_default=False, default=''))
        x_axes_data = [[] for _ in range(num_x_axes)]
        y_axes_data = [[] for _ in range(num_y_axes)]


        # for x data
        for i in range(num_x_axes):
            user_input1 = click.prompt(
           "\n1. Option - v, Enter values\n" "2. Option - c, Use cclib and extract the data\n" 
           "How you want to enter x axis values (v/c)", show_default=False, default='')
            if user_input1=='v':
                x_data = click.prompt(f'Enter a range of x-axis {(i+1)} values separated by commas',show_default=False, default='')
                m_x_data = [int(x.strip()) for x in  x_data.split(',')]
                x_axes_data[i].extend(m_x_data)
            elif user_input1=='c':
                click.echo("choose the .log calculation file you want to parse")                
                file_parse = select_file()
                data = cclib.io.ccopen(file_parse).parse()
                attribute_names = list(data.__dict__.keys())
                for atr in attribute_names:
                    click.echo(atr)
                #tik jei attriburte array rank 1
                user_input3 = click.prompt('Enter the name of the attribute you want to choose for x axis',show_default=False, default='')
                if user_input3 in attribute_names:
                    x_data = getattr(data, user_input3)
                    if isinstance(x_data, np.ndarray):
                        x_data = x_data.tolist()
                    click.echo(f"The parsed attribute '{user_input3}' is: {x_data}")
                 #vibfreqs = data.vibfreqs
        #vibirs = data.vibirs
        #vibramans = data.vibramans    
                else:
                    click.echo("Invalid attribute name.")
                x_axes_data[i].extend(x_data)
      # for y data
        for j in range(num_y_axes):
            user_input2 = click.prompt(
           "\n1. Option - v, Enter values\n" "2. Option - c, Use cclib and extract the data\n" 
           "How you want to enter y axis values (v/c)", show_default=False, default='')
            if user_input2=='v':
                y_data = click.prompt(f'Enter a range of y-axis {(j+1)} values separated by commas',show_default=False, default='')
                m_y_data = [int(y.strip()) for y in  y_data.split(',')]
                y_axes_data[j].extend(m_y_data)
            elif user_input2=='c':
                click.echo("choose the .log calculation file you want to parse")                
                file_parse = select_file()
                data = cclib.io.ccopen(file_parse).parse()
                attribute_names = list(data.__dict__.keys())
                for atr in attribute_names:
                    click.echo(atr)
                #tik jei attriburte array rank 1
                user_input4 = click.prompt('Enter the name of the attribute you want to choose for y axis',show_default=False, default='')
                if user_input4 in attribute_names:
                    y_data = getattr(data, user_input4)
                    if isinstance(y_data, np.ndarray):
                        y_data = y_data.tolist()
                    click.echo(f"The parsed attribute '{user_input4}' is: {y_data}")
                else:
                    click.echo("Invalid attribute name.")
                y_axes_data[j].extend(y_data)
        # the plotting
        title = click.prompt('Enter the title for the graph', type=str)
        x_label = click.prompt('Enter the label for the X-axis', type=str)
        y_label = click.prompt('Enter the label for the Y-axis', type=str)
        print(x_axes_data)
        print(y_axes_data)
         # save to .txt
        columns = ['x_data', 'y_data']
        data_txt = list(zip(x_axes_data,y_axes_data))
        click.echo('Extracted data')
        click.echo(tabulate(data_txt, headers=columns))
    
        with open('data.txt', 'w', newline='') as file:
            writer = csv.writer(file, delimiter='\t')  # Using tab delimiter for .txt file
            writer.writerow(columns)  # Write column names
            writer.writerows(data_txt)  # Write data
        fig, ax = plt.subplots()
        # Plot the graph
        for x_data, y_data in zip(x_axes_data, y_axes_data):
            user_input5 = click.prompt("Do you want to data as line or dots (l/d)", show_default=False, default='')
            if user_input5=='l':
                ax.plot(x_data, y_data, linestyle='-', linewidth=1, label=f'X-axis {x_axes_data.index(x_data)+1} and Y-axis {y_axes_data.index(y_data)+1}')
            elif user_input5=='d':
                ax.scatter(x_data, y_data, label=f'X-axis {x_axes_data.index(x_data)+1} and Y-axis {y_axes_data.index(y_data)+1}')
       
        ax.set_xlabel(x_label)
        ax.set_ylabel(y_label)
        ax.set_title(title)
        ax.legend()
        plt.show()
         # Save the plot as bytes
        buffer = io.BytesIO()
        fig.savefig(buffer, format='png')
        buffer.seek(0)
        graph = buffer.read()

        #insert data to database
        user_input3 = click.prompt("Do you want to insert calculations to database? (y/n)", show_default=False, default='')       
        if user_input3=='y':
            title = click.prompt("Enter the job title", show_default=False, default='')
            # Write the data to the text file
            with open('data.txt', 'w', newline='') as file:
                writer = csv.writer(file, delimiter='\t')
                writer.writerow(columns)
                writer.writerows(data_txt)
            # Read the file as binary data
            with open('data.txt', 'rb') as file:
                file_data = file.read()
            c.execute("INSERT INTO Grafiku_viz (title,txt_file,graph) VALUES (?,?,?)", (title,file_data,graph))
            click.echo('Data was inserted sucessfully')
        else:
            click.echo('Calculations are finished')    
        os.remove('data.txt')
        connection.commit()
        connection.close()

    elif user_input4 == 's':
        click.echo("All data")
        c.execute('SELECT title FROM Grafiku_viz')
        all_titles = c.fetchall()
        for t in all_titles:
            click.echo(t)
        while True:
            user_input6 = click.prompt("Enter the job title", show_default=False, default='')
            c.execute('SELECT txt_file FROM Grafiku_viz WHERE title=?', (user_input6,))
            data_t = c.fetchall()
            if data_t:
                for row in data_t:
                    txt_file = row[0]
                    txt_file_str = txt_file.decode('utf-8')
                    lines = txt_file_str.split('\n')
                    for line in lines:
                        click.echo(line)
            c.execute('SELECT graph FROM Grafiku_viz WHERE title=?', (user_input6,))
            graph_data = c.fetchone()
            if graph_data:
                buffer = io.BytesIO(graph_data[0])
                buffer.seek(0)
                plt.figure()
                img = plt.imread(buffer)
                plt.imshow(img)
                plt.axis('off')
                plt.show()
            user_input5 = click.prompt("Do you want to see more jobs?(y/n)", show_default=False, default='')
            if user_input5.lower() != 'y':
                click.echo("You decided to leave")
                break
        connection.commit()
        connection.close()
if __name__=="__main__":
    user_input1 = click.prompt(
        "\n1. Option - 1, Insert\n" "2. Option - 2, Selecet\n" "3. Option - 3, Delete \n" "4. Option - 4, Excited states vs distance analysis\n"
        "5. Option - 5, Raman and absorbtion spectrum analysis\n" "6. Option - 6, Jmol\n" "7. Option - 7, Graphs vizualization\n""Select which action you want to choose", show_default=False, default='')
    if user_input1=='1':
        insert_all2()
    elif user_input1=='2':
        select_data2()
    elif user_input1=='3':
        delete_data()
    elif user_input1=='4':
        pirmas_grafikas()
    elif user_input1=='5':
        antras_grafikas_2()
    elif user_input1=='6':
        jmol()
    elif user_input1=='7':
        graph_viz()
        
    else:
        click.echo("You inserted wrong option, try again.")
    #print('hello world')
  
